export interface NFCData {
  trackingNumber?: string;
  packageId?: string;
  status?: string;
  [key: string]: any;
}

export class NFCManager {
  private reader: any = null;
  private isSupported: boolean;

  constructor() {
    this.isSupported = 'NDEFReader' in window;
  }

  async checkPermission(): Promise<boolean> {
    if (!this.isSupported) return false;
    
    try {
      const permission = await navigator.permissions.query({ name: 'nfc' as any });
      return permission.state === 'granted';
    } catch {
      // Fallback - assume permission is available
      return true;
    }
  }

  async scan(): Promise<NFCData> {
    if (!this.isSupported) {
      throw new Error("NFC is not supported on this device");
    }

    this.reader = new (window as any).NDEFReader();
    
    try {
      await this.reader.scan();
      
      return new Promise((resolve, reject) => {
        this.reader.addEventListener("reading", ({ message }: any) => {
          try {
            const record = message.records[0];
            if (record.recordType === "text") {
              const textDecoder = new TextDecoder();
              const data = textDecoder.decode(record.data);
              
              try {
                const nfcData = JSON.parse(data);
                resolve(nfcData);
              } catch {
                resolve({ trackingNumber: data });
              }
            }
          } catch (error) {
            reject(error);
          }
        });

        this.reader.addEventListener("readingerror", () => {
          reject(new Error("Error reading NFC tag"));
        });
      });
    } catch (error) {
      throw new Error("Failed to start NFC scan");
    }
  }

  async write(data: NFCData): Promise<void> {
    if (!this.isSupported) {
      throw new Error("NFC is not supported on this device");
    }

    const writer = new (window as any).NDEFReader();
    
    try {
      await writer.write({
        records: [{
          recordType: "text",
          data: JSON.stringify(data)
        }]
      });
    } catch (error) {
      throw new Error("Failed to write to NFC tag");
    }
  }

  stop(): void {
    if (this.reader) {
      try {
        this.reader.stop?.();
      } catch (error) {
        console.log("Error stopping NFC reader:", error);
      }
      this.reader = null;
    }
  }

  get supported(): boolean {
    return this.isSupported;
  }
}

export const nfcManager = new NFCManager();
