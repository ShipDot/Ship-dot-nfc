interface StatsCardProps {
  icon: React.ReactNode;
  label: string;
  value: number;
}

export default function StatsCard({ icon, label, value }: StatsCardProps) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-2">
        {icon}
        <span className="text-sm text-gray-600">{label}</span>
      </div>
      <span className="font-semibold text-lg">{value}</span>
    </div>
  );
}
