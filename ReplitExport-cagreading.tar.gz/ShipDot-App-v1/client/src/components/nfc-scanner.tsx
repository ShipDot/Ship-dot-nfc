import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useNFC } from "@/hooks/use-nfc";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { NfcIcon, QrCode, X, CheckCircle } from "lucide-react";

interface NFCScannerProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export default function NFCScanner({ isOpen = false, onClose }: NFCScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedPackage, setScannedPackage] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isSupported, startScan, stopScan } = useNFC();

  const scanMutation = useMutation({
    mutationFn: async (trackingNumber: string) => {
      const response = await apiRequest("POST", "/api/nfc/read", { trackingNumber });
      return response.json();
    },
    onSuccess: (data) => {
      setScannedPackage(data.package);
      setIsScanning(false);
      toast({
        title: "Package Found!",
        description: "Successfully read package information",
      });
    },
    onError: () => {
      setIsScanning(false);
      toast({
        title: "Scan Failed",
        description: "Could not read NFC tag or find package",
        variant: "destructive",
      });
    },
  });

  const handleStartScan = async () => {
    if (!isSupported) {
      toast({
        title: "NFC Not Supported",
        description: "Your device doesn't support NFC scanning",
        variant: "destructive",
      });
      return;
    }

    setIsScanning(true);
    try {
      const result = await startScan();
      if (result) {
        // Extract tracking number from NFC data
        const trackingNumber = result.trackingNumber || "PKG-001234"; // Fallback for demo
        scanMutation.mutate(trackingNumber);
      }
    } catch (error) {
      setIsScanning(false);
      toast({
        title: "Scan Error",
        description: "Failed to read NFC tag",
        variant: "destructive",
      });
    }
  };

  const handleClose = () => {
    if (isScanning) {
      stopScan();
      setIsScanning(false);
    }
    setScannedPackage(null);
    onClose?.();
  };

  const handleQRFallback = () => {
    // Simulate QR code scan for demo
    setTimeout(() => {
      scanMutation.mutate("PKG-001234");
    }, 1000);
  };

  useEffect(() => {
    if (isOpen && !scannedPackage) {
      handleStartScan();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="max-w-md">
        {isScanning ? (
          <>
            <DialogHeader>
              <DialogTitle className="text-center">Scanning for NFC Tag</DialogTitle>
            </DialogHeader>
            <div className="text-center py-6">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <NfcIcon className="h-8 w-8 text-shipdot-primary" />
              </div>
              <p className="text-sm text-gray-600 mb-6">
                Hold your device near the NFC tag to read package information
              </p>
              
              <div className="space-y-3">
                <Button 
                  onClick={handleQRFallback}
                  className="w-full bg-shipdot-success hover:bg-green-700"
                >
                  <QrCode className="h-4 w-4 mr-2" />
                  Use QR Code Instead
                </Button>
                <Button 
                  onClick={handleClose}
                  variant="outline" 
                  className="w-full"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </>
        ) : scannedPackage ? (
          <>
            <DialogHeader>
              <DialogTitle className="text-center flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                Package Found!
              </DialogTitle>
            </DialogHeader>
            <div className="text-center py-4">
              <p className="text-sm text-gray-600 mb-4">
                Successfully read package information
              </p>
              
              <Card className="mb-6">
                <CardContent className="p-4 space-y-2 text-left">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Tracking:</span>
                    <span className="font-medium">{scannedPackage.trackingNumber}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Status:</span>
                    <Badge className="bg-green-100 text-green-800 capitalize">
                      {scannedPackage.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Destination:</span>
                    <span className="font-medium">
                      {scannedPackage.recipientCity}, {scannedPackage.recipientState}
                    </span>
                  </div>
                  {scannedPackage.estimatedDelivery && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">ETA:</span>
                      <span className="font-medium">
                        {new Date(scannedPackage.estimatedDelivery).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <div className="space-y-3">
                <Button className="w-full bg-shipdot-primary hover:bg-blue-700">
                  Update Status
                </Button>
                <Button 
                  onClick={handleClose}
                  variant="outline" 
                  className="w-full"
                >
                  Close
                </Button>
              </div>
            </div>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="text-center">NFC Scanner</DialogTitle>
            </DialogHeader>
            <div className="text-center py-6">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <NfcIcon className="h-8 w-8 text-shipdot-success" />
              </div>
              <p className="text-sm font-medium text-gray-900 mb-2">Scanner Ready</p>
              <p className="text-xs text-gray-500 mb-6">Hold device near NFC tag</p>
              <Button 
                onClick={handleStartScan}
                className="w-full bg-shipdot-primary hover:bg-blue-700 mb-3"
              >
                Start NFC Scan
              </Button>
              <Button 
                onClick={handleClose}
                variant="outline" 
                className="w-full"
              >
                Close
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
