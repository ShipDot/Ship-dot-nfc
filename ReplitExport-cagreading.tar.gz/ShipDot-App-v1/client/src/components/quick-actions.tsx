import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { NfcIcon, Plus, Printer, QrCode } from "lucide-react";
import NFCScanner from "./nfc-scanner";

export default function QuickActions() {
  const [, setLocation] = useLocation();
  const [showNFCScanner, setShowNFCScanner] = useState(false);

  const actions = [
    {
      title: "Scan NFC Tag",
      subtitle: "Tap to read package info",
      icon: NfcIcon,
      color: "bg-primary hover:bg-primary/90",
      onClick: () => setShowNFCScanner(true),
    },
    {
      title: "Create Package",
      subtitle: "Register new shipment",
      icon: Plus,
      color: "bg-secondary hover:bg-secondary/90",
      onClick: () => setLocation("/create"),
    },
    {
      title: "Print Labels",
      subtitle: "NFC & QR labels",
      icon: Printer,
      color: "bg-accent hover:bg-accent/90",
      onClick: () => {},
    },
    {
      title: "Scan QR Code",
      subtitle: "Fallback scanning",
      icon: QrCode,
      color: "bg-primary/80 hover:bg-primary/70",
      onClick: () => {},
    },
  ];

  return (
    <>
      <div className="mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {actions.map((action, index) => (
            <Button
              key={index}
              onClick={action.onClick}
              className={`${action.color} text-white p-6 h-auto flex flex-col items-center space-y-2 transition-colors`}
            >
              <action.icon className="h-6 w-6" />
              <span className="font-medium">{action.title}</span>
              <span className="text-xs opacity-90">{action.subtitle}</span>
            </Button>
          ))}
        </div>
      </div>

      {showNFCScanner && (
        <NFCScanner 
          isOpen={showNFCScanner} 
          onClose={() => setShowNFCScanner(false)} 
        />
      )}
    </>
  );
}
