import { Package } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Box, CheckCircle, Clock, Truck, NfcIcon, QrCode } from "lucide-react";
import { useLocation } from "wouter";

interface PackageCardProps {
  package: Package;
}

const statusConfig = {
  created: { 
    label: "Created", 
    color: "bg-blue-100 text-blue-800", 
    icon: Box,
    bgColor: "bg-blue-100",
    iconColor: "text-material-blue"
  },
  processing: { 
    label: "Processing", 
    color: "bg-yellow-100 text-yellow-800", 
    icon: Clock,
    bgColor: "bg-orange-100",
    iconColor: "text-material-orange"
  },
  in_transit: { 
    label: "In Transit", 
    color: "bg-green-100 text-green-800", 
    icon: Truck,
    bgColor: "bg-green-100",
    iconColor: "text-green-600"
  },
  delivered: { 
    label: "Delivered", 
    color: "bg-green-100 text-green-800", 
    icon: CheckCircle,
    bgColor: "bg-green-100",
    iconColor: "text-green-600"
  },
};

export default function PackageCard({ package: pkg }: PackageCardProps) {
  const [, setLocation] = useLocation();
  const statusInfo = statusConfig[pkg.status as keyof typeof statusConfig];
  const StatusIcon = statusInfo?.icon || Box;

  const handleClick = () => {
    setLocation(`/package/${pkg.id}`);
  };

  const getDestination = () => {
    return `${pkg.recipientCity}, ${pkg.recipientState}`;
  };

  const getTimeAgo = () => {
    if (!pkg.createdAt) return "Created recently";
    const now = new Date();
    const created = new Date(pkg.createdAt);
    const diffInHours = Math.floor((now.getTime() - created.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Created less than 1 hour ago";
    if (diffInHours === 1) return "Created 1 hour ago";
    if (diffInHours < 24) return `Created ${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) return "Created yesterday";
    return `Created ${diffInDays} days ago`;
  };

  const getDeliveryInfo = () => {
    if (pkg.status === "delivered" && pkg.deliveredAt) {
      const delivered = new Date(pkg.deliveredAt);
      return `Delivered ${delivered.toLocaleDateString()} at ${delivered.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    
    if (pkg.estimatedDelivery) {
      const estimated = new Date(pkg.estimatedDelivery);
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      if (estimated.toDateString() === tomorrow.toDateString()) {
        return "Est. delivery: Tomorrow";
      }
      
      const diffInDays = Math.ceil((estimated.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
      if (diffInDays <= 1) return "Est. delivery: Today";
      return `Est. delivery: ${diffInDays} days`;
    }
    
    return "Delivery date pending";
  };

  // Simulate NFC vs QR based on package type
  const hasNFC = pkg.packageType === "standard" || pkg.packageType === "express";

  return (
    <Card 
      className="border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer"
      onClick={handleClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${statusInfo?.bgColor} rounded-lg flex items-center justify-center`}>
              <StatusIcon className={`h-5 w-5 ${statusInfo?.iconColor}`} />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{pkg.trackingNumber}</h3>
              <p className="text-sm text-gray-600">{getDestination()}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={statusInfo?.color}>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-current rounded-full" />
                <span>{statusInfo?.label}</span>
              </div>
            </Badge>
            {hasNFC ? (
              <NfcIcon className="h-4 w-4 text-material-blue" />
            ) : (
              <QrCode className="h-4 w-4 text-gray-400" />
            )}
          </div>
        </div>
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>{getTimeAgo()}</span>
          <span>{getDeliveryInfo()}</span>
        </div>
      </CardContent>
    </Card>
  );
}
