import { useState, useCallback } from "react";

interface NFCData {
  trackingNumber?: string;
  packageId?: string;
  [key: string]: any;
}

export function useNFC() {
  const [isSupported, setIsSupported] = useState(() => {
    // Check if Web NFC is supported
    return 'NDEFReader' in window;
  });

  const [isScanning, setIsScanning] = useState(false);
  const [reader, setReader] = useState<any>(null);

  const startScan = useCallback(async (): Promise<NFCData | null> => {
    if (!isSupported) {
      throw new Error("NFC is not supported on this device");
    }

    try {
      setIsScanning(true);
      
      // Create new NDEFReader instance
      const ndefReader = new (window as any).NDEFReader();
      setReader(ndefReader);

      await ndefReader.scan();

      return new Promise((resolve, reject) => {
        ndefReader.addEventListener("reading", ({ message, serialNumber }: any) => {
          console.log(`> Serial Number: ${serialNumber}`);
          console.log(`> Records: (${message.records.length})`);

          try {
            // Parse NFC data
            const record = message.records[0];
            if (record.recordType === "text") {
              const textDecoder = new TextDecoder(record.encoding);
              const data = textDecoder.decode(record.data);
              
              // Try to parse as JSON
              try {
                const nfcData = JSON.parse(data);
                resolve(nfcData);
              } catch {
                // If not JSON, assume it's a tracking number
                resolve({ trackingNumber: data });
              }
            } else {
              resolve({ trackingNumber: "PKG-001234" }); // Fallback for demo
            }
          } catch (error) {
            reject(error);
          } finally {
            setIsScanning(false);
          }
        });

        ndefReader.addEventListener("readingerror", () => {
          reject(new Error("Error reading NFC tag"));
          setIsScanning(false);
        });

        // Simulate successful scan after 2 seconds for demo
        setTimeout(() => {
          resolve({ trackingNumber: "PKG-001234" });
          setIsScanning(false);
        }, 2000);
      });
    } catch (error) {
      setIsScanning(false);
      throw error;
    }
  }, [isSupported]);

  const writeNFC = useCallback(async (data: NFCData): Promise<boolean> => {
    if (!isSupported) {
      throw new Error("NFC is not supported on this device");
    }

    try {
      const ndefReader = new (window as any).NDEFReader();
      
      await ndefReader.write({
        records: [{
          recordType: "text",
          data: JSON.stringify(data)
        }]
      });

      return true;
    } catch (error) {
      console.error("Error writing to NFC tag:", error);
      throw error;
    }
  }, [isSupported]);

  const stopScan = useCallback(() => {
    if (reader) {
      // Stop scanning if supported
      try {
        reader.stop?.();
      } catch (error) {
        console.log("Error stopping NFC scan:", error);
      }
    }
    setIsScanning(false);
    setReader(null);
  }, [reader]);

  return {
    isSupported,
    isScanning,
    startScan,
    writeNFC,
    stopScan,
  };
}
