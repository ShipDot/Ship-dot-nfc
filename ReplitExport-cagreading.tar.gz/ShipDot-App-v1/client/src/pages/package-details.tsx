import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Package } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Package as PackageIcon, MapPin, Clock, Truck, CheckCircle, NfcIcon, QrCode } from "lucide-react";
import { useLocation } from "wouter";

const statusConfig = {
  created: { label: "Created", color: "bg-blue-100 text-blue-800", icon: PackageIcon },
  processing: { label: "Processing", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  in_transit: { label: "In Transit", color: "bg-green-100 text-green-800", icon: Truck },
  delivered: { label: "Delivered", color: "bg-green-100 text-green-800", icon: CheckCircle },
};

export default function PackageDetails() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: pkg, isLoading } = useQuery<Package>({
    queryKey: ["/api/packages", params.id],
  });

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const response = await apiRequest("PATCH", `/api/packages/${params.id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/packages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Status Updated",
        description: "Package status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update package status.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-surface">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
            <div className="bg-white rounded-lg p-6 space-y-4">
              <div className="h-6 bg-gray-200 rounded w-1/3"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!pkg) {
    return (
      <div className="min-h-screen bg-surface">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center">
            <PackageIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h2 className="text-lg font-medium text-gray-900 mb-2">Package Not Found</h2>
            <p className="text-gray-600 mb-4">The package you're looking for doesn't exist.</p>
            <Button onClick={() => setLocation("/")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const statusInfo = statusConfig[pkg.status as keyof typeof statusConfig];
  const StatusIcon = statusInfo?.icon || PackageIcon;

  return (
    <div className="min-h-screen bg-surface">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium text-gray-900 flex items-center">
                    <StatusIcon className="h-5 w-5 mr-2" />
                    {pkg.trackingNumber}
                  </CardTitle>
                  <Badge className={statusInfo?.color}>
                    {statusInfo?.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium text-gray-900 mb-3 flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      Sender Information
                    </h3>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p className="font-medium">{pkg.senderName}</p>
                      <p>{pkg.senderAddress}</p>
                      <p>{pkg.senderCity}, {pkg.senderState} {pkg.senderZip}</p>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900 mb-3 flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      Recipient Information
                    </h3>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p className="font-medium">{pkg.recipientName}</p>
                      <p>{pkg.recipientAddress}</p>
                      <p>{pkg.recipientCity}, {pkg.recipientState} {pkg.recipientZip}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Package Type</p>
                    <p className="text-sm text-gray-600 capitalize">{pkg.packageType}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Weight</p>
                    <p className="text-sm text-gray-600">{pkg.weight} lbs</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Dimensions</p>
                    <p className="text-sm text-gray-600">{pkg.dimensions}</p>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h3 className="font-medium text-gray-900 mb-3">Update Status</h3>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(statusConfig).map(([status, config]) => (
                      <Button
                        key={status}
                        variant={pkg.status === status ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateStatusMutation.mutate(status)}
                        disabled={updateStatusMutation.isPending || pkg.status === status}
                        className={pkg.status === status ? "bg-shipdot-primary" : ""}
                      >
                        <config.icon className="h-4 w-4 mr-1" />
                        {config.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-gray-900">
                  Package Timeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <PackageIcon className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Package Created</p>
                      <p className="text-xs text-gray-500">
                        {pkg.createdAt ? new Date(pkg.createdAt).toLocaleString() : "Unknown"}
                      </p>
                    </div>
                  </div>
                  
                  {pkg.status !== "created" && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                        <Clock className="h-4 w-4 text-yellow-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Processing Started</p>
                        <p className="text-xs text-gray-500">Updated recently</p>
                      </div>
                    </div>
                  )}

                  {(pkg.status === "in_transit" || pkg.status === "delivered") && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <Truck className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">In Transit</p>
                        <p className="text-xs text-gray-500">Package shipped</p>
                      </div>
                    </div>
                  )}

                  {pkg.status === "delivered" && pkg.deliveredAt && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Delivered</p>
                        <p className="text-xs text-gray-500">
                          {new Date(pkg.deliveredAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-gray-900">
                  Smart Label
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mx-auto">
                    <NfcIcon className="h-8 w-8 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">NFC Label Active</p>
                    <p className="text-xs text-gray-500">Tap device to read package info</p>
                  </div>
                  <div className="space-y-2">
                    <Button className="w-full bg-shipdot-primary hover:bg-blue-700" size="sm">
                      <NfcIcon className="h-4 w-4 mr-2" />
                      Write NFC Tag
                    </Button>
                    <Button variant="outline" className="w-full" size="sm">
                      <QrCode className="h-4 w-4 mr-2" />
                      Generate QR Code
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
