import { useQuery } from "@tanstack/react-query";
import { Package } from "@shared/schema";
import Header from "@/components/header";
import QuickActions from "@/components/quick-actions";
import PackageCard from "@/components/package-card";
import StatsCard from "@/components/stats-card";
import NFCScanner from "@/components/nfc-scanner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, Box, Truck, CheckCircle } from "lucide-react";

export default function Dashboard() {
  const { data: packages, isLoading: packagesLoading } = useQuery<Package[]>({
    queryKey: ["/api/packages"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<{
    created: number;
    processing: number;
    inTransit: number;
    delivered: number;
    nfcActive: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const recentPackages = packages?.slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-surface">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <QuickActions />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium text-gray-900">
                    Recent Shipments
                  </CardTitle>
                  <Select defaultValue="today">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {packagesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="border rounded-lg p-4">
                        <div className="flex items-center space-x-3 mb-2">
                          <Skeleton className="w-10 h-10 rounded-lg" />
                          <div className="space-y-1">
                            <Skeleton className="h-4 w-24" />
                            <Skeleton className="h-3 w-32" />
                          </div>
                        </div>
                        <div className="flex justify-between">
                          <Skeleton className="h-3 w-24" />
                          <Skeleton className="h-3 w-32" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : recentPackages.length > 0 ? (
                  <div className="space-y-4">
                    {recentPackages.map((pkg) => (
                      <PackageCard key={pkg.id} package={pkg} />
                    ))}
                    <div className="text-center mt-4">
                      <Button variant="ghost" className="text-material-blue hover:text-blue-700">
                        View All Shipments <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Box className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No packages found</p>
                    <p className="text-sm text-gray-500">Create your first package to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-medium text-gray-900">
                  Today's Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                {statsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex justify-between items-center">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-6 w-8" />
                      </div>
                    ))}
                  </div>
                ) : stats ? (
                  <div className="space-y-4">
                    <StatsCard
                      icon={<Box className="h-5 w-5 text-material-blue" />}
                      label="Packages Created"
                      value={stats.created}
                    />
                    <StatsCard
                      icon={<Truck className="h-5 w-5 text-green-600" />}
                      label="In Transit"
                      value={stats.inTransit}
                    />
                    <StatsCard
                      icon={<CheckCircle className="h-5 w-5 text-green-600" />}
                      label="Delivered"
                      value={stats.delivered}
                    />
                    <StatsCard
                      icon={<div className="w-5 h-5 text-material-blue">NFC</div>}
                      label="NFC Tags Active"
                      value={stats.nfcActive}
                    />
                  </div>
                ) : (
                  <p className="text-gray-500">Failed to load statistics</p>
                )}
              </CardContent>
            </Card>

            <NFCScanner />
          </div>
        </div>
      </div>
    </div>
  );
}
