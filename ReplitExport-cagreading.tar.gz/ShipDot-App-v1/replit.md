# ShipDot App

## Overview
ShipDot App is a modern shipping management application built with React and Node.js that specializes in NFC (Near Field Communication) technology for smart shipping labels. The application provides a comprehensive solution for creating, managing, and tracking packages with ShipDot smart labels featuring both NFC tags and QR codes as fallback options. ShipDot replaces traditional shipping labels with intelligent, trackable smart labels.

## Recent Changes
- **July 29, 2025**: Migrated from in-memory storage to PostgreSQL database for persistent data storage
- **July 29, 2025**: Integrated custom ShipDot orange circular logo and updated brand colors to warm orange theme
- **July 29, 2025**: Deployed complete DatabaseStorage implementation with automatic sample data initialization

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query (React Query) for server state
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with warm orange brand colors matching the ShipDot circular logo
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database**: PostgreSQL with Drizzle ORM (migrated from in-memory storage on July 29, 2025)
- **Database Provider**: Replit PostgreSQL database
- **Session Storage**: PostgreSQL-based sessions using connect-pg-simple
- **Development**: TSX for TypeScript execution in development

### Key Components

#### Database Schema
- **Packages Table**: Core package information including tracking numbers, status, sender/recipient details, dimensions, and timestamps
- **Labels Table**: NFC and QR code label data associated with packages
- **Status Tracking**: Package lifecycle management (created → processing → in_transit → delivered)

#### API Structure
- RESTful API with CRUD operations for packages and labels
- Package endpoints: GET /api/packages, POST /api/packages, GET /api/packages/:id
- Tracking lookup: GET /api/packages/tracking/:trackingNumber
- Statistics endpoint: GET /api/stats for dashboard metrics
- NFC integration endpoints for reading/writing tag data

#### NFC Integration
- Web NFC API implementation for modern browsers
- NFC tag reading and writing capabilities
- Graceful fallback to QR codes for unsupported devices
- Real-time package status updates via NFC scanning

## Data Flow

1. **Package Creation**: Users create packages through a form interface, generating unique tracking numbers
2. **Label Generation**: System creates both NFC tags and QR codes for each package
3. **Package Tracking**: NFC scanning or manual lookup updates package status in real-time
4. **Status Updates**: Package status flows through defined states with timestamp tracking
5. **Dashboard Analytics**: Real-time statistics aggregation for operational insights

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React, React DOM, React Hook Form with Zod validation
- **UI Components**: Comprehensive Radix UI component library
- **Styling**: Tailwind CSS with PostCSS processing
- **Icons**: Lucide React icon library

### Backend Dependencies
- **Database**: Drizzle ORM, Neon Database serverless PostgreSQL
- **Validation**: Zod schema validation shared between client and server
- **Session Management**: Express sessions with PostgreSQL storage
- **Development Tools**: TSX, ESBuild for production builds

### NFC Technology
- **Web NFC API**: Browser-native NFC support for modern devices
- **Fallback Support**: QR code generation and scanning for broader device compatibility
- **Progressive Enhancement**: Application works without NFC, enhanced with NFC when available

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite dev server with HMR for React components
- **API Development**: Express server with automatic TypeScript compilation
- **Database**: Live connection to Neon PostgreSQL for development
- **Error Handling**: Runtime error overlay for debugging

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild compiles TypeScript server to `dist/index.js`
- **Static Assets**: Express serves built frontend from production build
- **Database Migrations**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Database URL**: Required environment variable for PostgreSQL connection
- **Build Scripts**: Separate development and production execution paths
- **Asset Management**: Proper static file serving in production mode

## Recent Changes
- **January 2025**: Rebranded application to "ShipDot App" with custom brand colors
- **Brand Colors**: Implemented ShipDot brand color scheme with primary blue (hsl(220, 85%, 60%)), secondary blue, accent orange, and success green
- **Logo System**: Created modular logo component ready for custom logo integration
- **UI Consistency**: Updated all components to use ShipDot branding consistently throughout the application

The application follows a modern, type-safe development approach with shared schemas between client and server, comprehensive error handling, and a mobile-first responsive design optimized for warehouse and logistics environments.