import { type Package, type InsertPackage, type Label, type InsertLabel, PackageStatus, packages, labels } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Package operations
  getPackage(id: string): Promise<Package | undefined>;
  getPackageByTrackingNumber(trackingNumber: string): Promise<Package | undefined>;
  createPackage(packageData: InsertPackage): Promise<Package>;
  updatePackage(id: string, updates: Partial<Package>): Promise<Package | undefined>;
  getAllPackages(): Promise<Package[]>;
  getPackagesByStatus(status: string): Promise<Package[]>;
  
  // Label operations
  getLabel(id: string): Promise<Label | undefined>;
  getLabelByPackageId(packageId: string): Promise<Label | undefined>;
  createLabel(labelData: InsertLabel): Promise<Label>;
  updateLabel(id: string, updates: Partial<Label>): Promise<Label | undefined>;
  getAllLabels(): Promise<Label[]>;
  
  // Statistics
  getPackageStats(): Promise<{
    created: number;
    processing: number;
    inTransit: number;
    delivered: number;
    nfcActive: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize database with sample data if empty
    this.initializeSampleDataIfNeeded();
  }

  private async initializeSampleDataIfNeeded() {
    try {
      const existingPackages = await db.select().from(packages).limit(1);
      if (existingPackages.length === 0) {
        // Create sample packages for development
        const samplePackages = [
          {
            trackingNumber: "AUS-001234",
            status: PackageStatus.IN_TRANSIT,
            packageType: "standard",
            priority: "standard",
            senderName: "Melbourne Distribution Centre",
            senderAddress: "45 Port Melbourne Industrial Estate",
            senderCity: "Melbourne",
            senderState: "VIC",
            senderZip: "3207",
            recipientName: "Sarah Williams",
            recipientAddress: "23 George Street",
            recipientCity: "Sydney",
            recipientState: "NSW",
            recipientZip: "2000",
            weight: "2.5",
            dimensions: "30 x 20 x 15",
            estimatedDelivery: new Date(Date.now() + 86400000), // Tomorrow
          },
          {
            trackingNumber: "AUS-001235",
            status: PackageStatus.PROCESSING,
            packageType: "express",
            priority: "high",
            senderName: "Brisbane Logistics Hub",
            senderAddress: "78 Gateway Drive",
            senderCity: "Brisbane",
            senderState: "QLD",
            senderZip: "4000",
            recipientName: "Michael Chen",
            recipientAddress: "15 Collins Street",
            recipientCity: "Perth",
            recipientState: "WA",
            recipientZip: "6000",
            weight: "1.2",
            dimensions: "20 x 15 x 10",
            estimatedDelivery: new Date(Date.now() + 172800000), // 2 days
          },
          {
            trackingNumber: "AUS-001233",
            status: PackageStatus.DELIVERED,
            packageType: "standard",
            priority: "standard",
            senderName: "Adelaide Warehouse",
            senderAddress: "92 Industrial Drive",
            senderCity: "Adelaide",
            senderState: "SA",
            senderZip: "5000",
            recipientName: "Emma Thompson",
            recipientAddress: "67 King William Street",
            recipientCity: "Adelaide",
            recipientState: "SA",
            recipientZip: "5000",
            weight: "3.1",
            dimensions: "25 x 25 x 20",
            deliveredAt: new Date(Date.now() - 3600000), // 1 hour ago
          },
        ];

        for (const pkg of samplePackages) {
          await this.createPackage(pkg);
        }
      }
    } catch (error) {
      console.log("Sample data initialization skipped:", error);
    }
  }

  async getPackage(id: string): Promise<Package | undefined> {
    const [pkg] = await db.select().from(packages).where(eq(packages.id, id));
    return pkg || undefined;
  }

  async getPackageByTrackingNumber(trackingNumber: string): Promise<Package | undefined> {
    const [pkg] = await db.select().from(packages).where(eq(packages.trackingNumber, trackingNumber));
    return pkg || undefined;
  }

  async createPackage(packageData: InsertPackage): Promise<Package> {
    let trackingNumber = packageData.trackingNumber;
    
    // Generate tracking number if not provided
    if (!trackingNumber) {
      trackingNumber = `PKG-${Date.now().toString().slice(-6)}`;
    }
    
    const [pkg] = await db
      .insert(packages)
      .values({
        ...packageData,
        trackingNumber,
      })
      .returning();
    
    return pkg;
  }

  async updatePackage(id: string, updates: Partial<Package>): Promise<Package | undefined> {
    const [updatedPackage] = await db
      .update(packages)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(packages.id, id))
      .returning();
    
    return updatedPackage || undefined;
  }

  async getAllPackages(): Promise<Package[]> {
    return await db.select().from(packages).orderBy(packages.createdAt);
  }

  async getPackagesByStatus(status: string): Promise<Package[]> {
    return await db.select().from(packages).where(eq(packages.status, status));
  }

  async getLabel(id: string): Promise<Label | undefined> {
    const [label] = await db.select().from(labels).where(eq(labels.id, id));
    return label || undefined;
  }

  async getLabelByPackageId(packageId: string): Promise<Label | undefined> {
    const [label] = await db.select().from(labels).where(eq(labels.packageId, packageId));
    return label || undefined;
  }

  async createLabel(labelData: InsertLabel): Promise<Label> {
    const [label] = await db
      .insert(labels)
      .values({
        packageId: labelData.packageId,
        labelType: labelData.labelType || "nfc",
        nfcData: labelData.nfcData || null,
        qrCode: labelData.qrCode || null,
        printStatus: labelData.printStatus || "pending",
      })
      .returning();
    
    return label;
  }

  async updateLabel(id: string, updates: Partial<Label>): Promise<Label | undefined> {
    const [updatedLabel] = await db
      .update(labels)
      .set(updates)
      .where(eq(labels.id, id))
      .returning();
    
    return updatedLabel || undefined;
  }

  async getAllLabels(): Promise<Label[]> {
    return await db.select().from(labels).orderBy(labels.createdAt);
  }

  async getPackageStats() {
    const allPackages = await db.select().from(packages);
    const allLabels = await db.select().from(labels);
    
    return {
      created: allPackages.filter(p => p.status === PackageStatus.CREATED).length,
      processing: allPackages.filter(p => p.status === PackageStatus.PROCESSING).length,
      inTransit: allPackages.filter(p => p.status === PackageStatus.IN_TRANSIT).length,
      delivered: allPackages.filter(p => p.status === PackageStatus.DELIVERED).length,
      nfcActive: allLabels.filter(l => l.labelType === "nfc").length,
    };
  }
}

export const storage = new DatabaseStorage();
