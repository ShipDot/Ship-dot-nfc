import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPackageSchema, insertLabelSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Package routes
  app.get("/api/packages", async (req, res) => {
    try {
      const packages = await storage.getAllPackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch packages" });
    }
  });

  app.get("/api/packages/:id", async (req, res) => {
    try {
      const pkg = await storage.getPackage(req.params.id);
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch package" });
    }
  });

  app.get("/api/packages/tracking/:trackingNumber", async (req, res) => {
    try {
      const pkg = await storage.getPackageByTrackingNumber(req.params.trackingNumber);
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch package" });
    }
  });

  app.post("/api/packages", async (req, res) => {
    try {
      const packageData = insertPackageSchema.parse(req.body);
      const pkg = await storage.createPackage(packageData);
      res.status(201).json(pkg);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid package data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create package" });
    }
  });

  app.patch("/api/packages/:id", async (req, res) => {
    try {
      const updates = req.body;
      const pkg = await storage.updatePackage(req.params.id, updates);
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ message: "Failed to update package" });
    }
  });

  // Label routes
  app.get("/api/labels", async (req, res) => {
    try {
      const labels = await storage.getAllLabels();
      res.json(labels);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch labels" });
    }
  });

  app.get("/api/labels/package/:packageId", async (req, res) => {
    try {
      const label = await storage.getLabelByPackageId(req.params.packageId);
      if (!label) {
        return res.status(404).json({ message: "Label not found" });
      }
      res.json(label);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch label" });
    }
  });

  app.post("/api/labels", async (req, res) => {
    try {
      const labelData = insertLabelSchema.parse(req.body);
      const label = await storage.createLabel(labelData);
      res.status(201).json(label);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid label data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create label" });
    }
  });

  app.patch("/api/labels/:id", async (req, res) => {
    try {
      const updates = req.body;
      const label = await storage.updateLabel(req.params.id, updates);
      if (!label) {
        return res.status(404).json({ message: "Label not found" });
      }
      res.json(label);
    } catch (error) {
      res.status(500).json({ message: "Failed to update label" });
    }
  });

  // Statistics route
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getPackageStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // NFC operations
  app.post("/api/nfc/read", async (req, res) => {
    try {
      const { trackingNumber } = req.body;
      if (!trackingNumber) {
        return res.status(400).json({ message: "Tracking number required" });
      }

      const pkg = await storage.getPackageByTrackingNumber(trackingNumber);
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }

      res.json({ 
        success: true, 
        package: pkg,
        message: "NFC tag read successfully" 
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to read NFC tag" });
    }
  });

  app.post("/api/nfc/write", async (req, res) => {
    try {
      const { packageId, nfcData } = req.body;
      if (!packageId || !nfcData) {
        return res.status(400).json({ message: "Package ID and NFC data required" });
      }

      // Create or update label with NFC data
      let label = await storage.getLabelByPackageId(packageId);
      if (label) {
        label = await storage.updateLabel(label.id, { nfcData, labelType: "nfc" });
      } else {
        label = await storage.createLabel({
          packageId,
          labelType: "nfc",
          nfcData,
          printStatus: "pending",
        });
      }

      res.json({ 
        success: true, 
        label,
        message: "NFC tag written successfully" 
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to write NFC tag" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
