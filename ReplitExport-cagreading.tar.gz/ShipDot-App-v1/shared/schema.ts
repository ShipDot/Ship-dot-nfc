import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const packages = pgTable("packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackingNumber: text("tracking_number").notNull().unique(),
  status: text("status").notNull().default("created"), // created, processing, in_transit, delivered
  packageType: text("package_type").notNull().default("standard"),
  priority: text("priority").notNull().default("standard"), // standard, high, critical
  
  // Sender information
  senderName: text("sender_name").notNull(),
  senderAddress: text("sender_address").notNull(),
  senderCity: text("sender_city").notNull(),
  senderState: text("sender_state").notNull(),
  senderZip: text("sender_zip").notNull(),
  
  // Recipient information
  recipientName: text("recipient_name").notNull(),
  recipientAddress: text("recipient_address").notNull(),
  recipientCity: text("recipient_city").notNull(),
  recipientState: text("recipient_state").notNull(),
  recipientZip: text("recipient_zip").notNull(),
  
  // Package details
  weight: text("weight"),
  dimensions: text("dimensions"), // L x W x H format
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  estimatedDelivery: timestamp("estimated_delivery"),
  deliveredAt: timestamp("delivered_at"),
});

export const labels = pgTable("labels", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  packageId: varchar("package_id").notNull().references(() => packages.id),
  labelType: text("label_type").notNull().default("nfc"), // nfc, qr
  nfcData: json("nfc_data"), // NFC tag data
  qrCode: text("qr_code"), // QR code data
  printStatus: text("print_status").notNull().default("pending"), // pending, printed, error
  createdAt: timestamp("created_at").defaultNow(),
  printedAt: timestamp("printed_at"),
});

export const insertPackageSchema = createInsertSchema(packages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deliveredAt: true,
});

export const insertLabelSchema = createInsertSchema(labels).omit({
  id: true,
  createdAt: true,
  printedAt: true,
});

export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type Package = typeof packages.$inferSelect;
export type InsertLabel = z.infer<typeof insertLabelSchema>;
export type Label = typeof labels.$inferSelect;

// Status enums
export const PackageStatus = {
  CREATED: "created",
  PROCESSING: "processing", 
  IN_TRANSIT: "in_transit",
  DELIVERED: "delivered",
} as const;

export const Priority = {
  STANDARD: "standard",
  HIGH: "high",
  CRITICAL: "critical",
} as const;

export const LabelType = {
  NFC: "nfc",
  QR: "qr",
} as const;
